# ANW Bronhouder Capability Statement v1.0 - XML Representation - Netherlands - ANW implementation guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ANW Bronhouder Capability Statement v1.0**

## : ANW Bronhouder Capability Statement v1.0 - XML Representation

| |
| :--- |
| Active as of 2025-10-15 |

[Raw xml](CapabilityStatement-ANWBronhouderCapabilityStatement-v1.xml) | [Download](CapabilityStatement-ANWBronhouderCapabilityStatement-v1.xml)

