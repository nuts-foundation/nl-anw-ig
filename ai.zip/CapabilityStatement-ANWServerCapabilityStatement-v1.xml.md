# ANW Server Capability Statement v1.0 - XML Representation - Netherlands - ANW implementation guide v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ANW Server Capability Statement v1.0**

## : ANW Server Capability Statement v1.0 - XML Representation

| |
| :--- |
| Active as of 2025-10-15 |

[Raw xml](CapabilityStatement-ANWServerCapabilityStatement-v1.xml) | [Download](CapabilityStatement-ANWServerCapabilityStatement-v1.xml)

