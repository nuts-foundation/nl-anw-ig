# Home - Netherlands - ANW implementation guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:http://nuts-foundation.github.io/nl-generic-anw-ig/ImplementationGuide/nl.nuts.anw | *Version*:0.1.0 |
| Draft as of 2026-03-02 | *Computable Name*:NLAnwIG |

## ⚠️ Disclaimer

> **Belangerijk:**
 Op plekken op deze site kan verwezen worden naar fhir versie r4, dit is onterecht en een limitatie van de gebruikte technologie voor het modeleren van de capability statements en documentatie. Binnen de ANW use case die hier beschreven wordt, wordt er enkel gebruik gemaakt van fhir **STU3**.

# ANW Implementation Guide


This implementation guide defines FHIR profiles, extensions, and other resources needed for the ANW (Avond-, Nacht- en Weekendzorg) use case in the Netherlands.

## Overview

The ANW use case covers evening, night, and weekend care services. This implementation guide provides the necessary FHIR resources to support data exchange for these healthcare services.

## Contents

* [Artifacts](artifacts.md) - Profiles, extensions, and other FHIR artifacts defined in this IG
* [Technical documentation (NL)](technical-documentation-v1.md) - Technical documentation in Dutch

## Authors and Contributors

* **Publisher**: Stichting Nuts
* **Contact**: [https://www.nuts.nl](https://www.nuts.nl)

